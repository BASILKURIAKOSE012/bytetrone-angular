import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProductsComponent } from './products/products.component';
import { ProductdetailComponent } from './productdetail/productdetail.component';



@NgModule({
  declarations: [
    ProductsComponent,
    ProductdetailComponent
  ],
  imports: [
    CommonModule
  ]
})
export class ProductModule { }
