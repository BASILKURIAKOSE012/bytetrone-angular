export class Product {

    constructor(public id:string ,public title:String,public price:number,
        public category:string,public image:string ,public description:string){}
}
